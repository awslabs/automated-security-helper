"""Helpers the entry point uses."""


def greeting(name):
    """The line printed for one name."""
    return f"hello, {name}"


def total(names):
    """How many names there are."""
    return len(list(names))
