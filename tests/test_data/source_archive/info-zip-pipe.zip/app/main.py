"""Entry point of the fixture project."""

from app.util.helpers import greeting, total


def main(names):
    """Print a greeting for each name and return how many there were."""
    for name in names:
        print(greeting(name))
    return total(names)


if __name__ == "__main__":
    raise SystemExit(0 if main(["ada", "grace", "edsger"]) == 3 else 1)
