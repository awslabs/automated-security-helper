# Fixture project

Small on purpose: a few text files, one empty file, one binary file and one
file that compresses to almost nothing.
