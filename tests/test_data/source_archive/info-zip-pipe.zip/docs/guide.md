# Guide

The entry point is `app/main.py`. It greets each name it is given and returns
how many names there were.

## Layout

- `app/` holds the code.
- `bin/run.sh` runs the entry point.
- `data/` holds two files: one that compresses well and one that does not.
- `docs/` holds this guide.
